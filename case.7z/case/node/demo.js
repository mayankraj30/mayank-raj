//*******************lab 3 node====
var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser');
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;


/**
 * Displaying all data from file
 */
exp.use(cors());
exp.use(parser.json());

exp.route('/getFileData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        console.log(_fileData);
        res.send(_fileData);
        res.end();
    });
})

/**
 * Displaying specific city in file
 */

exp.route('/getEmpData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        //console.log(_fileData);
        for(let emp of _fileData)
            if(emp.empAddress.city === "Pune"){
                console.log(emp.empId+" "+emp.empName);
                res.send(emp.empId+" "+emp.empName);
            }
        res.end();
    });
})

/**
 * Updating city of employee in file
 */

exp.route('/updateEmpData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        //console.log(_fileData);
        for(i=0; i<_fileData.length; i++)
            if(_fileData[i].empAddress.city === "Pune"){
                console.log("Before: ",_fileData[i].empAddress.city);
                _fileData[i].empAddress.city = "Pune Hinjewadi";
                console.log("After: ",_fileData[i].empAddress.city);
                res.send(_fileData[i].empAddress.city);
            }
        fs.writeFileSync("employees.json", JSON.stringify(_fileData));
        res.end();
    });
})

/**
 * Adding new employee in file
 */

exp.route('/addEmpData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        var emp = {"empId":1007,"empName":"Adam","empSalary":55000,"empAddress":{"city":"San Jose","state":"California"}}
        _fileData.push(emp);
        fs.writeFileSync("employees.json", JSON.stringify(_fileData));
        res.send(_fileData);
        res.end();
    });
})

/**
 * Adding all file data to MongoDB database
 */

exp.route('/file2db', cors()).post((req, res)=>{
    console.log('file2db Invoked....');
    var fileData;
    fs.readFile('employees.json', function(err, data) {
        //res.writeHead(200, {'Content-Type': 'text/plain'});
        fileData = JSON.parse(data.toLocaleString());
        console.log(fileData);
        //res.end();
    });

    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){
        console.log('In Mongo Client',fileData);
        if(err) throw err;
        var coll = dbvar.db('test');        
        coll.collection('test').insertMany(fileData, true, function(err, result){
            if(err) throw err;
            console.log('document inserted....');
            res.send(fileData);
            res.end();
            dbvar.close();
        });
        dbvar.close();
    });
})



/**
 * Displaying employee belong to specific state in MongoDB
 */

exp.route('/dbstate', cors()).post((req, res)=>{

    MongoClient.connect('mongodb://localhost:27017/test', { useNewUrlParser: true }, function(err, dbvar){          console.log("ZX");
        if(err) throw err;
        var coll = dbvar.db('test'); 
        
        coll.collection('test').find({"empAddress.state": "Maharashtra"}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})

/**
 * updating employee city in mongodb
 */

exp.route('/updateEmp', cors()).put((req, res)=>{

    MongoClient.connect('mongodb://localhost:27017/test', { useNewUrlParser: true }, function(err, dbvar){
        if(err) throw err;
        var coll = dbvar.db('test');        
        coll.collection('test').updateOne({empId: (req.body).empId}, {$set: {"empAddress.city": (req.body).city}}, true, function(err, result){
            if(err) throw err;
            console.log('One document Updated....');            
            dbvar.close();
        });
        dbvar.close();
    });
})

/**
 * Adding employee to mongodb
 */

exp.route('/addEmp', cors()).post((req, res)=>{
    var emp = {"empId":1008,"empName":"John","empSalary":65000,"empAddress":{"city":"New York","state":"California"}}
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){
        
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').insertOne(emp, true, function(err, res){
            if(err) throw err;
            console.log('One document inserted....');
            dbvar.close();
            res.end();
        });
        dbvar.close();
    });
})

exp.use(cors()).listen(3000, ()=>console.log("RUNNING...."));










//***********Lab2 node**************
var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');

var MongoClient = require('mongodb').MongoClient;

var products = [
  {
    "productId": 1001,
    "productName" : "Mobile",
    "productCost" : 15320,
    "ProductDesc" : "VoLTE Enabled"
	},
  {
    "productId": 1002,
    "productName" : "Car",
    "productCost" : 455320,
    "ProductDesc" : "Good"
	},
  {
    "productId": 1003,
    "productName" : "Bus",
    "productCost" : 15320,
    "ProductDesc" : "Electric Bus"
	}
]

exp.use(cors());

/**
 * Adding data to MongoDB
 */

exp.use(parser.json());
exp.route('/addProduct', cors()).post((req, res)=>{

    res.status(200).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',req.body);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').insertMany(products, true, function(err, result){
            if(err) throw err;
            console.log('One document inserted....');
            dbvar.close();
        });
        dbvar.close();
    });
})


/**
 * Getting all data from MongoDB
 */

exp.use(parser.json());
exp.route('/getProducts', cors()).get((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',req.body);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').find().toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})


/**
 * Getting data based on product id from MongoDB
 */

exp.use(parser.json());
exp.route('/getProduct/id', cors()).post((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',(req.body).productId);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').find({"productId": (req.body).productId}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})


/**
 * Deleting data based on product id from MongoDB
 */

exp.use(parser.json());
exp.route('/deleteProduct', cors()).delete((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',(req.body).productId);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').deleteOne({"productId": (req.body).productId}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})

/**
 * Updating data based on product id from MongoDB
 */

exp.use(parser.json());
exp.route('/updateProduct', cors()).put((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',(req.body).productId);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').update({"productId": (req.body).productId},{$set:{productCost: 405000}}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})

exp.use(cors()).listen(3000, ()=>console.log("RUNNING...."));



//*******end lab 2 node**************


var http = require('http');

const {parse}=require('querystring');

const server = http.createServer(function (req, res) {
    if (req.method === 'POST') {
       let body='';
       req.on('data',chunk=>{
           body+=chunk.toString();
       })
       req.on('end',()=>{
           console.log(body);
           x=parse(body);
           res.end(`username=${x.uname} password=${x.upass}`);
       })
    }
    else {
        res.end(`
        <!doctype html>
        <html>
        <body>
        <form action="/" method="post">
        UserName:-<input type="text" name="uname" /><br/>
        Password:-<input type="password" name="upass" /><br/>
        <button>save</button>
        </form>
        </body>
        </html>
    `);
    }

});
server.listen(4000);

//****************************express se



var express = require('express');  
var app = express();
var bodyParser =require('body-parser')

app.get('/', function (req, res) {
   res.sendFile( __dirname + "/Prob1.4.html" );
});


var urlencodedParser = bodyParser.urlencoded({ extended: true });
app.post('/RegistrationSuccessPage',urlencodedParser, function (req, res) {
   var uname = req.body.username
   var pwd = req.body.pwd
   console.log("hiiiiiiiiiiiiiiiiiiiii")
  
    postData = "Your Name is :"+ uname+"\n" +"Your Password is :"+ pwd
   console.log(postData);
   res.send(">>>>"+postData)
    
   //res.sendFile(  "/registrationSuccess.html",postData);
    res.end()
});

app.listen(4000,function(){
    console.log("Running")
}
=======================================================
<html>
<head>
</head>
<body>
    <div>   
        <div align="center">
          <form action="/RegistrationSuccessPage" method="post">
            <label>Please enter below details</label><br><br>
            <label>Username *: </label><input type="username" name="username"/><br><br>
            <label>Password *: </label><input type="password" name="pwd" /><br><br>         
            
            <br><br>
            <input type="submit" value="Submit" />
            </form>
        </div>
    </div>
</body>
</html>