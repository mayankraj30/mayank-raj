var http=require('http');
var express=require('express');
var app=express();
var fs=require('fs');
var cors=require('cors');
var parser=require('body-parser');
var dat=require('./products.json')
app.use(cors());
app.use(parser.json());

//fetching data from the json file and dislaying the data

app.route('/getFileData',cors()).get((req,res)=>{
    console.log("get file data api invoked");
    res.send(dat);
    res.end();
})

app.route('/delete/:id',cors()).delete((req,res)=>{
    console.log("delete invoked")
    id=req.params.id;
    for(e in dat){
        if(dat[e].productId==id){
            
            dat.splice(e,1)
            break;
        }
    }
    res.send(dat);
    fs.writeFileSync("products.json",JSON.stringify(dat));
})

app.route('/adddataToFile',cors()).post((req,res)=>{
    console.log(req.body);
    var x=dat;
    x.push(req.body)
    res.send(x);
    fs.writeFileSync('products.json',JSON.stringify(x));
    res.end();

})

app.route('/editFileData',cors()).post((req,res)=>{
    
    console.log('file2db Invoked....')   
    fs.readFile('products.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        //console.log(_fileData);
        for(i=0; i<_fileData.length; i++)
            if(_fileData[i].productId ===req.body.productId ){
                
                _fileData[i].productName = req.body.productName;
                _fileData[i].productDescription = req.body.productDescription;
                _fileData[i].productPrice = req.body.productPrice;
                
                
            }
        fs.writeFileSync("products.json", JSON.stringify(_fileData));
        res.send(_fileData);
        res.end();
    });
})




app.listen(4001,function(){
    console.log("Running")
})