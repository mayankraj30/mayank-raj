import { Injectable,OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http'; 

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  constructor(private http:HttpClient) { }


ngOnInit(){
  this.getData();
}





//getting data from the url provided by the api made in express file


  getData():Observable<any>{
    return this.http.get<any[]>("http://localhost:4001/getFileData");

  }
  
  //deleting data from the file

  deleteProduct(id):Observable<any[]>{
    return this.http.delete<any[]>("http://localhost:4001/delete/"+id);
  }

  //adding data to the file
  
  postData(pId:number,pName:string,pDescription:string,pPrice):Observable<any>{

    return this.http.post<any[]>("http://localhost:4001/adddataToFile",{
      productId:pId,
      productName:pName,
      productDescription:pDescription,
      productPrice:pPrice

    });
  }

updateData(pId:number,pName:string,pDescription:string,pPrice):Observable<any>{

    return this.http.post<any[]>("http://localhost:4001/editFileData",{
      productId:pId,
      productName:pName,
      productDescription:pDescription,
      productPrice:pPrice

    });
  }



}
