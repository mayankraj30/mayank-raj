import { Component, OnInit } from '@angular/core';
import {ProductserviceService} from '../productservice.service';
import {NgForm} from '@angular/forms';
import {IProduct} from '../IProduct';
 
@Component({
  selector: 'app-product-display-component',
  templateUrl: './product-display-component.component.html',
  styleUrls: ['./product-display-component.component.css']
})
export class ProductDisplayComponentComponent implements OnInit {

  constructor(private productService:ProductserviceService) { }
fileData:any[]=[];
product:IProduct={
  'productId':null,
  'productName':"",
  'productDescription':"",
  'productPrice':null
};
  ngOnInit() {
    this.displayData();
  }
p=1;

  //displaying data by using service variable 
  displayData(){
    this.productService.getData().subscribe(data=>this.fileData=data);

  }

  deleteProduct(id){
    this.productService.deleteProduct(id).subscribe((fileData: any[]) => this.fileData = fileData);
  }



  addProduct(form:NgForm){
    var value=form.value;
    // console.log(value.id);
    // console.log(value.name);
    // console.log(value.description);console.log(value.price);
    this.productService.postData(value.id,value.name,value.description,value.price).subscribe((data:any[])=>this.fileData = data)
    form.resetForm();
$("#addProduct").modal('hide');

    
  }

  updateProduct(form:NgForm){
     var value=form.value;
    this.productService.updateData(value.id,value.name,value.description,value.price).subscribe((data:any[])=>this.fileData = data)
 form.resetForm();
$("#editProduct").modal('hide');  

}

  populateProduct(data:IProduct){
    this.product.productId=data.productId;
    this.product.productName=data.productName;
    this.product.productDescription=data.productDescription;
    this.product.productPrice=data.productPrice;
  }

}
