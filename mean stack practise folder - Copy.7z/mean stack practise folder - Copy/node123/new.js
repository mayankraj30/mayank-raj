var express=require('express');
var qs=require('qs');

var exp=express();
var x=exp.post('/submit',function(request,response){
    response.writeHead(200, { 'Content-Type': 'text/html' });
    response.write("<h1>some post</h1>"+ request.query.id*3);
    response.end();

}).listen(3000);