var http = require('http');
var fs = require('fs');
http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' })
    // res.write("<h1>hello world this is nod e.js now i have changed</h1>");
    // res.write(req.url);
    // res.write("sdbjfsfhsd");
    // if (req.url == '/mayank') {
        // res.write("<body bgcolor='red'> <center><a href='/kullu'>call kullu</a></center></body>"); 
        // fs.readFile('show.html', function (error, data) {
        //     // res.writeHead(200, { 'Content-Type': 'text/html' });
        //     // res.write(data);
            res.end();

        });
    }

    //  if(req.url=='/kullu'){
    //     res.write("<body bgcolor='green'> <marquee>mayank is here</marquee></body>"); 
    // }





}).listen(3000);



// var server=function(req,res){

// }
// var request = require("request");
// 	request("http://www.google.com",function(error,response,body)
// 	{
// 		console.log(body);
// 	});