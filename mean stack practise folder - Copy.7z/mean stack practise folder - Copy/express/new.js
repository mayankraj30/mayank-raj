var http=require('http');
var express=require('express')
var parser=require('body-parser')
var exp=express();
var fs=require('fs');
var cors = require('cors')

var corsOptions = {
  origin: 'http://localhost:4200',
  
}

exp.get("/rest/api/load",cors(),(req,res)=>{
    console.log("Load Invoked")
    res.send({msg:'give some rest to world'})
}).listen(3000)

exp.route("/rest/api/get",cors()).get((req,res)=>{
    console.log("Load Invoked")
    res.send({msg:'give some rest to world'})
}).listen(3000)

exp.use(parser.json());
exp.route('/rest/api/post',cors()).post((req,res)=>{
    console.log(req.body);
    fs.writeFileSync('demo.json',JSON.stringify(req.body))
    res.status(201).send(req.body)
}).listen(3000)



***************new********

var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');

var corsOptions = {
  origin: 'http://localhost:4200',  
}

exp.get('/rest/api/load', cors(), (req, res)=> {
    console.log('Load Invoked....');
    res.send({msg: 'GIVE SOME REST TO WORLD....'});
})

exp.route('/rest/api/get', cors()).get((req, res)=>{
    console.log('GET Invoked....');
    res.send({msg: 'GET WORLD....'});
})

exp.use(parser.json());
exp.route('/rest/api/post', cors()).post((req, res)=>{
    console.log(req.body);
    fs.writeFileSync('demo.json', JSON.stringify(req.body));
    res.status(201).send(req.body);
})
exp.route('/rest/api/get/:name').get((req, res)=>{
    res.send('Hello World'+req.params['name']);
})
exp.use(cors()).listen(3000, ()=>console.log("RUNNING...."));
