var express = require('express');
var session=require('client-sessions');
var exp=express();
exp.set("view engine","jade")

exp.use(session({
    cookieName: 'uniqueid',
    secret: 'anyvalue',
    duration: 30*60*1000, //session time period
}));

exp.get('/createsession/:name',function(req,res){
    var name=req.params['name'];
    console.log(req.params[name]);
    req.uniqueid.name=name;

    if(name='abc'){
        res.render('sample',{name});
    }
    else
    {
        res.render('index',{name:req.uniqueid.name});
    }

});

exp.get('/extendsession',function(req,res){
    res.render('hello',{name:req.uniqueid.name});
});


exp.get('/logout',function(req,res){
    req.uniqueid.reset();
});

exp.listen(3001,()=>{
    console.log("jade running");
})