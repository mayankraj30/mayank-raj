var exp=require('express');
var view=exp();
view.set("view engine","jade")
view.get('/jade',function(err,res){
    res.render('hello');
});

view.listen(3001,()=>{
    console.log("jade running");
})