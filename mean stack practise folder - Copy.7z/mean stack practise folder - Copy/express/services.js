var http = require('http');
var express = require('express');
var exp = express();
var body = require('body-parser');
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient



exp.use(body());
exp.use(cors());
exp.use(body.json());
//api to post data from the front end or browser to the databse

exp.route('/rest/api/post', cors()).post((req, res) => {
    console.log(req.body);
    fs.appendFileSync('demo.json', JSON.stringify(req.body));
    res.status(201).send(req.body);

    //inserting the data to the database
    MongoClient.connect('mongodb://localhost:27017/data', function (err, dbconn) {
        if (err) throw err
        var database = dbconn.db('data');
        database.collection('empdata').insert(req.body, true, function (err, res) {
            if (err) throw err;
            console.log("1 document inserted");
     
            dbconn.close();
        })
        dbconn.close();
    })
})


//api to get data from the database and display the data on the browser
exp.route("/rest/api/get", cors()).get((req, res) => {
    console.log('get inovked');
   // res.send({ msg: 'world' });

    MongoClient.connect('mongodb://localhost:27017/data', function (err, dbconnection) {
        if (err) throw err
        var database = dbconnection.db('data');
        database.collection('empdata').find().toArray(function (err, result) {
            if (err) throw err
            console.log(result);
            res.send(result);
            dbconnection.close();
        })
        dbconnection.close();



    })

});

//4.delete specific data from  database
exp.route('/rest/api/deleteData', cors()).post((req, res) => {
    console.log("id isxxxx: "+(req.body).id);
    res.status(201).send(req.body);
    MongoClient.connect("mongodb://localhost:27017/data", function (err, dbVar) {
        if (err) throw err;
        var coll = dbVar.db('data');
        coll.collection('empdata').deleteMany({"name": (req.body).name}, function (err, obj) {
            if (err) throw err;
            console.log("1 document deleted");
            dbVar.close();
        });
        dbVar.close();
    });
})




//api to load data

exp.get("/rest/api/load", cors(), (req, res) => {
    console.log("load invoked");
    res.send({ msg: 'give some rest to world' });
});









exp.route('/rest/api/get/:name').get((req, res) => {
    res.send("Hello World" + req.params['name']);
});



//code to enable port to run these services

exp.use(cors()).listen(3000, () => console.log('running'));