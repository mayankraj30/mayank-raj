import { Injectable,OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http'; 

@Injectable({
  providedIn: 'root'
})
export class ExpressServiceService {

  constructor(private http:HttpClient) { 



  }

  ngOnInit() {
            this.getData();
  }


   getData():Observable<any>{

  return this.http.get<any[]>("http://localhost:3000/rest/api/get");
  



}

   postData(ename:string,eage:number,egender:string):Observable<any>{
     console.log("Ename"+ename);
     console.log("Eage"+eage);


  return this.http.post("http://localhost:3000/rest/api/post",{
    name:ename,
    age:eage,
    gender:egender
  });
  



}




}
