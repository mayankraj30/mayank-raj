import { TestBed, inject } from '@angular/core/testing';

import { ExpressServiceService } from './express-service.service';

describe('ExpressServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ExpressServiceService]
    });
  });

  it('should be created', inject([ExpressServiceService], (service: ExpressServiceService) => {
    expect(service).toBeTruthy();
  }));
});
