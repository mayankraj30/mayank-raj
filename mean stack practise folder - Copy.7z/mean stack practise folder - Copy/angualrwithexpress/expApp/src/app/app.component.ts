import { Component, OnInit } from '@angular/core';
import {ExpressServiceService} from './express-service.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  title = 'app';
str:any;
// aaa:any[]=[];
data:any[]=[];
  constructor(private expressService:ExpressServiceService) { }

  // ngOnInit() {
  //   this.invokeGet();
  // }

invokeGet(){
  this.expressService.getData().subscribe(d=>this.data=d);
}

uname:string;
uage:number;
ugender:string;
invokePost()
{
  console.log(this.uname,this.uage,this.ugender);
  this.expressService.postData(this.uname,this.uage,this.ugender).subscribe((data:any)=>{})
}


}
