var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');

var MongoClient = require('mongodb').MongoClient;

exp.use(cors());
exp.use(parser.json());


//posting data to the mongodb database

exp.route('/addProduct', cors()).post((req, res)=>{

    res.status(200).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',req.body);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').insertMany(products, true, function(err, result){
            if(err) throw err;
            console.log('One document inserted....');
            dbvar.close();
        });
        dbvar.close();
    });
})

//reading data from mongo db

exp.route('/getProducts', cors()).get((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',req.body);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').find().toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})

//updating data in mongo db


exp.route('/updateProduct', cors()).put((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',(req.body).productId);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').update({"productId": (req.body).productId},{$set:{productCost: 405000}}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})

//deleteing data from mongo db


exp.route('/deletePost', cors()).delete((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',(req.body).productId);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').deleteOne({"productId": (req.body).productId}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})







