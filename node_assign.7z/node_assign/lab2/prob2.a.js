
var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');

var MongoClient = require('mongodb').MongoClient;

var products = [
  {
    "productId": 1001,
    "productName" : "Mobile",
    "productCost" : 15320,
    "ProductDesc" : "VoLTE Enabled"
	},
  {
    "productId": 1002,
    "productName" : "Car",
    "productCost" : 455320,
    "ProductDesc" : "Good"
	},
  {
    "productId": 1003,
    "productName" : "Bus",
    "productCost" : 15320,
    "ProductDesc" : "Electric Bus"
	}
]

exp.use(cors());

/**
 * Adding data to MongoDB
 */

exp.use(parser.json());
exp.route('/addProduct', cors()).post((req, res)=>{

    res.status(200).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/productsDB', function(err, dbconnection){

        console.log('In Mongo Client',req.body);
        if(err) throw err;
        var coll = dbconnection.db('productsDB');
        coll.collection('productInfo').insertMany(products, true, function(err, result){
            if(err) throw err;
            console.log('One document inserted....');
            dbconnection.close();
        });
        dbconnection.close();
    });
})
exp.use(cors()).listen(3000, ()=>console.log("RUNNING...."));
