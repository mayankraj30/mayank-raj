var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;
exp.use(parser.json());
exp.route('/getProducts', cors()).get((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/productsDB', function(err, dbconnection){

        console.log('In Mongo Client',req.body);
        if(err) throw err;
        var coll = dbconnection.db('productsDB');
        coll.collection('productInfo').find().toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbconnection.close();
        })
        dbconnection.close();
    });
})
exp.use(cors()).listen(3000, ()=>console.log("RUNNING...."));