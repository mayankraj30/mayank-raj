var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser');
var fs = require('fs');
var cors = require('cors');
//var MongoClient = require('mongodb').MongoClient;


/**
 * Displaying all data from file
 */
exp.use(cors());
exp.use(parser.json());

exp.route('/getFileData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        console.log(_fileData);
        res.send(_fileData);
        res.end();
    });
})
exp.use(cors()).listen(3000, () => console.log('running'));