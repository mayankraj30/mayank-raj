var express = require('express');
var exp = express();
var body = require('body-parser');
var fs = require('fs');
var cors = require('cors');

//displaying all employees

exp.route('/rest/api/getjsonfile', cors()).get((req, res)=>{
     res.writeHead(200, {'Content-Type': 'text/json'});
    console.log('get data  Invoked....');
    var fileData;
    fs.readFile('employees.json', function(err, data) {
        fileData = data.toString();
        console.log(fileData);
    //    res.send(fileData);
        res.end(fileData);
    });
})
exp.use(cors()).listen(3000, () => console.log('running'));