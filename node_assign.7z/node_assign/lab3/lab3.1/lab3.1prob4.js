var express = require('express');
var exp = express();
var body = require('body-parser');
var fs = require('fs');
var cors = require('cors');


exp.route('/addEmpData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        var emp = {"empId":1007,"empName":"Adam","empSalary":55000,"empAddress":{"city":"San Jose","state":"California"}}
        _fileData.push(emp);
        fs.writeFileSync("employees.json", JSON.stringify(_fileData));
        res.send(_fileData);
        res.end();
    });
})
exp.use(cors()).listen(3000, () => console.log('running'));