var express = require('express');
var exp = express();
var body = require('body-parser');
var fs = require('fs');
var cors = require('cors');

exp.route('/updateEmpData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        //console.log(_fileData);
        for(i=0; i<_fileData.length; i++)
            if(_fileData[i].empAddress.city === "Pune"){
                console.log("Before: ",_fileData[i].empAddress.city);
                _fileData[i].empAddress.city = "Pune Hinjewadi";
                console.log("After: ",_fileData[i].empAddress.city);
                res.send(_fileData[i].empAddress.city);
            }
        fs.writeFileSync("employees.json", JSON.stringify(_fileData));
        res.end();
    });
})
exp.use(cors()).listen(3000, () => console.log('running'));
