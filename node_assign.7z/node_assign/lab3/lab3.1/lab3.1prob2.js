var express = require('express');
var exp = express();
var body = require('body-parser');
var fs = require('fs');
var cors = require('cors');

exp.route('/getEmpData', cors()).post((req, res)=>{
    console.log('file2db Invoked....')   
    fs.readFile('employees.json', function(err, data) {
        
        var _fileData = JSON.parse(data.toLocaleString());
        //console.log(_fileData);
        for(let emp of _fileData)
            if(emp.empAddress.city === "Pune"){
                console.log(emp.empId+" "+emp.empName);
                res.send(emp.empId+" "+emp.empName);
            }
        res.end();
    });
})

exp.use(cors()).listen(3000, () => console.log('running'));