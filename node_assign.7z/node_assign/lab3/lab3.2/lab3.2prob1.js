var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser');
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;




exp.route('/filedata', cors()).post((req, res)=>{
    console.log('file2db Invoked....');
    var fileData;
    fs.readFile('employees.json', function(err, data) {
        //res.writeHead(200, {'Content-Type': 'text/plain'});
        fileData = JSON.parse(data.toLocaleString());
        console.log(fileData);
        //res.end();
    });

    MongoClient.connect('mongodb://localhost:27017/infoDB', function(err, dbconnection){
        console.log('In Mongo Client',fileData);
        if(err) throw err;
        var coll = dbconnection.db('infoDB');        
        coll.collection('empInfo').insertMany(fileData, true, function(err, result){
            if(err) throw err;
            console.log('document inserted....');
            res.send(fileData);
            res.end();
            dbconnection.close();
        });
        dbconnection.close();
    });
})
exp.use(cors()).listen(3000, () => console.log('running'));