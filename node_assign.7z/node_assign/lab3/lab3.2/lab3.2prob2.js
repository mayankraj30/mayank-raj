var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser');
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;

exp.route('/dbstate', cors()).post((req, res)=>{

    MongoClient.connect('mongodb://localhost:27017/infoDB', { useNewUrlParser: true }, function(err, dbconnection){          console.log("ZX");
        if(err) throw err;
        var coll = dbconnection.db('infoDB'); 
        
        coll.collection('empInfo').find({"empAddress.state": "Maharashtra"}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbconnection.close();
        })
        dbconnection.close();
    });
})
exp.use(cors()).listen(3000, () => console.log('running'));