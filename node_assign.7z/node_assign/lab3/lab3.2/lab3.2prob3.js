var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser');
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;

exp.use(parser.json());

exp.route('/updateEmp', cors()).put((req, res)=>{

    MongoClient.connect('mongodb://localhost:27017/infoDB', { useNewUrlParser: true }, function(err, dbconnection){
        if(err) throw err;
        var coll = dbconnection.db('infoDB');        
        coll.collection('empInfo').updateOne({empId: (req.body).empId}, {$set: {"empAddress.city": (req.body).city}}, true, function(err, result){
            if(err) throw err;
            console.log('One document Updated....');            
            dbconnection.close();
        });
        dbconnection.close();
    });
})
exp.use(cors()).listen(3000, () => console.log('running'));