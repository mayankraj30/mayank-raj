var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser');
var fs = require('fs');
var cors = require('cors');
var MongoClient = require('mongodb').MongoClient;


exp.use(parser.json());

exp.route('/addEmp', cors()).post((req, res)=>{
    var emp = {"empId":1008,"empName":"John","empSalary":65000,"empAddress":{"city":"New York","state":"California"}}
    MongoClient.connect('mongodb://localhost:27017/infoDB', function(err, dbconnection){
        
        if(err) throw err;
        var coll = dbconnection.db('infoDB');
        coll.collection('empInfo').insertOne(emp, true, function(err, res){
            if(err) throw err;
            console.log('One document inserted....');
            dbconnection.close();
            res.end();
            
        });
        dbconnection.close();
    });
})
exp.use(cors()).listen(3000, () => console.log('running'));
