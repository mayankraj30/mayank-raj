var http = require('http');
var fs = require('fs');
http.createServer(function (req, res) {
  fs.readFile('file.txt', function(err, data) {
    res.writeHead(200, {'Content-Type': 'text/plain'});
   console.log(data.toString());
    res.end();
  });
}).listen(8080);

