var employees=["mayank","pawan","kuldeep","aditya","harshita","vinal"];

for(let emp of employees)
{
    console.log(emp);
}
