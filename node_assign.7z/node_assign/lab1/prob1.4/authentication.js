var http = require('http');

const {parse}=require('querystring');

const server = http.createServer(function (req, res) {
    if (req.method === 'POST') {
       let body='';
       req.on('data',chunk=>{
           body+=chunk.toString();
       })
       req.on('end',()=>{
           console.log(body);
           x=parse(body);
           res.end(`username=${x.uname} password=${x.upass}`);
       })
    }
    else {
        res.end(`
        <!doctype html>
        <html>
        <body>
        <form action="/" method="post">
        UserName:-<input type="text" name="uname" /><br/>
        Password:-<input type="password" name="upass" /><br/>
        <button>save</button>
        </form>
        </body>
        </html>
    `);
    }

});
server.listen(4000);