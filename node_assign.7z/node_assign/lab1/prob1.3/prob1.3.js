var fs = require('fs');

fs.writeFile('file.txt', 'Hello this is file written using node server', function (err) {
  if (err) throw err;
  console.log('Saved!');
});